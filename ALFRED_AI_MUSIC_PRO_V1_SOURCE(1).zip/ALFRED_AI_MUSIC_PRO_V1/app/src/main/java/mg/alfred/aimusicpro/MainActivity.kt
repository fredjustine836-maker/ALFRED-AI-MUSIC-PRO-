package mg.alfred.aimusicpro

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 10, 25)
    private val panel = Color.rgb(35, 23, 55)
    private val purple = Color.rgb(174, 91, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(205, 190, 220)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(28))
        }
        scroll.addView(root)

        val brand = TextView(this).apply {
            text = "ALFRED AI MUSIC PRO"
            textSize = 25f
            setTextColor(purple)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "CRÉÉ PAR ALFRED"
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, dp(18))
        }
        root.addView(subtitle, matchWrap())

        val intro = TextView(this).apply {
            text = "Mamorona hira • Cover • Texte ho feo"
            textSize = 16f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(14), dp(10), dp(14))
            setBackgroundColor(panel)
        }
        root.addView(intro, matchWrap())

        addAction(root, "🎤  COVER HIRA", "Ampidiro hira ary amboary amin'ny AI") {
            info("COVER HIRA", "Eto no hampidirana hira. Mbola mila ampifandraisina amin'ny motera AI fanovana feo ity asa ity.")
        }
        addAction(root, "🎼  CRÉATION DE CHANSON", "Tononkira + feo mihira + musique") {
            info("CRÉATION DE CHANSON", "Eto no hanoratana tononkira sy hisafidianana gadona. Mila motera AI music mifandray amin'ny Internet.")
        }
        addAction(root, "🗣️  TEXTE → VOIX", "Avadiho ho feo ny soratra") {
            info("TEXTE → VOIX", "Eto no hampidirana soratra sy hisafidianana feo. Mila ampifandraisina amin'ny motera Text-to-Speech.")
        }
        addAction(root, "🔐  ESPACE ADMIN", "Fangatahana sy autorisation") {
            info("ESPACE ADMIN", "Dika voalohany ihany ity. Aza mampiditra mot de passe tena izy: mbola tsy misy serveur Admin azo antoka.")
        }

        val price = TextView(this).apply {
            text = "TARIF PRÉVU : 10 000 Ar / HIRA\nPaiement prévu : Airtel Money\nAutorisation : Alfred ihany"
            textSize = 15f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(18), dp(14), dp(18))
            setBackgroundColor(panel)
        }
        val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.setMargins(0, dp(18), 0, dp(12))
        root.addView(price, p)

        val note = TextView(this).apply {
            text = "VERSION V1 — Interface de départ. Les fonctions IA, le paiement et les autorisations ne sont pas encore connectés."
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        root.addView(note, matchWrap())
        setContentView(scroll)
    }

    private fun addAction(root: LinearLayout, title: String, desc: String, onClick: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(13))
            setBackgroundColor(panel)
        }
        val t = TextView(this).apply {
            text = title
            textSize = 17f
            setTextColor(purple)
            typeface = Typeface.DEFAULT_BOLD
        }
        box.addView(t, matchWrap())
        val d = TextView(this).apply {
            text = desc
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(5), 0, dp(10))
        }
        box.addView(d, matchWrap())
        val button = Button(this).apply {
            text = "SOKAFY"
            setTextColor(white)
            setBackgroundColor(purple)
            setOnClickListener { onClick() }
        }
        box.addView(button, matchWrap())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(12), 0, 0)
        root.addView(box, lp)
    }

    private fun info(title: String, message: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
