# ALFRED AI MUSIC PRO — Source ZIP V1

**Créé par Alfred**

Ity no V1 amin'ny tetikasa Android. Ahitana interface voalohany volomparasy sy mainty, misy bokotra:
- COVER HIRA
- CRÉATION DE CHANSON
- TEXTE → VOIX
- ESPACE ADMIN

Vidiny kasaina: **10 000 Ar / hira**. Fandoavana kasaina: Airtel Money.

## Zava-dehibe
Ity ZIP ity dia **source code fanombohana**, fa tsy APK efa vita. Ny bokotra dia mampiseho fanazavana fotsiny amin'izao. Tsy mbola tafiditra:
- motera AI hanaovana cover / famoronana hira / Text-to-Speech;
- serveur sy tahiry angona ho an'ny kaonty Admin sy autorisation;
- fanamarinana fandoavam-bola Airtel Money;
- kaody activation sy fitantanana abonnement.

Tsy tokony hampidirina ao amin'ny APK ny mot de passe Admin na API key. Ny tena fanamarinana dia tokony hatao amin'ny serveur azo antoka.

## Fomba fanokafana amin'ny AndroidIDE
1. Sintomy ary esory (Extract) ity ZIP ity.
2. Sokafy AndroidIDE.
3. Safidio ny **Open Project** ary fidio ny lahatahiry `ALFRED_AI_MUSIC_PRO_V1` (ilay misy `settings.gradle`).
4. Avelao hisintona ny Gradle dependencies raha misy Internet.
5. Andramo ny Sync/Build.

Mety mila Android SDK/Gradle mifanaraka amin'ny findainao ny build. Raha misy error, alefaso ny sary an'ilay error mba hanampiana amin'ny fanamboarana.

## Fampahalalana ara-teknika
- Package: `mg.alfred.aimusicpro`
- Min SDK: 23
- Target SDK: 35
- Version: 1.0
